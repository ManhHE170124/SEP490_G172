import React from "react";
import { useNavigate } from "react-router-dom";
import AdminLayout from "../../components/admin/Layout";
import { ProductApi } from "../../services/products";
import { CategoryApi } from "../../services/categories";

export default function ProductAdd() {
  const nav = useNavigate();
  const [cats, setCats] = React.useState([]);
  const [saving, setSaving] = React.useState(false);
  const [form, setForm] = React.useState({
    productCode: "",
    productName: "",
    supplierId: 1,
    productType: "SOFTWARE",
    costPrice: 0,
    salePrice: 0,
    stockQty: 0,
    warrantyDays: 0,
    expiryDate: "",
    autoDelivery: false,
    status: "ACTIVE",
    description: "",
    categoryIds: [],
  });

  React.useEffect(() => {
    CategoryApi.list({ active: true }).then(setCats).catch(() => {});
  }, []);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const save = async (publish = true) => {
    try {
      setSaving(true);
      const payload = { ...form, status: publish ? form.status : "INACTIVE" };
      if (!payload.expiryDate) payload.expiryDate = null; // backend chấp nhận null
      await ProductApi.create(payload);
      alert(publish ? "Đã tạo & xuất bản sản phẩm" : "Đã lưu nháp sản phẩm");
      nav("/admin/products");
    } catch (e) {
      alert(e?.response?.data?.message || e.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <AdminLayout>
      <div className="card">
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
          <h2>Thêm sản phẩm</h2>
          <div className="row">
            <button className="btn ghost" onClick={() => nav("/admin/products")}>⬅ Quay lại</button>
            <button className="btn primary" disabled={saving} onClick={() => save(true)}>Lưu sản phẩm</button>
          </div>
        </div>

        <div className="grid cols-2">
          <div>
            <label>Tên sản phẩm</label>
            <input
              value={form.productName}
              onChange={(e) => set("productName", e.target.value)}
              placeholder="VD: Microsoft 365 Family"
            />
          </div>
          <div>
            <label>SKU</label>
            <input
              value={form.productCode}
              onChange={(e) => set("productCode", e.target.value)}
              placeholder="OFF_365_FAM"
            />
          </div>

          <div>
            <label>Danh mục</label>
            <select
              value={form.categoryIds[0] || ""}
              onChange={(e) => set("categoryIds", e.target.value ? [Number(e.target.value)] : [])}
            >
              <option value="">Chọn danh mục…</option>
              {cats.map((c) => (
                <option key={c.categoryId} value={c.categoryId}>
                  {c.categoryName}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label>Loại</label>
            <select value={form.productType} onChange={(e) => set("productType", e.target.value)}>
              <option value="SOFTWARE">Key cá nhân / phần mềm</option>
              <option value="LICENSE">Key dùng chung</option>
              <option value="SERVICE">Gói dịch vụ</option>
            </select>
          </div>

          <div>
            <label>Trạng thái hiển thị</label>
            <select value={form.status} onChange={(e) => set("status", e.target.value)}>
              <option value="ACTIVE">Hiển thị</option>
              <option value="INACTIVE">Ẩn</option>
              <option value="OUT_OF_STOCK">Hết hàng</option>
            </select>
          </div>
          <div />

          <div>
            <label>Giá bán (đ)</label>
            <input
              type="number"
              value={form.salePrice}
              onChange={(e) => set("salePrice", Number(e.target.value) || 0)}
              placeholder="349000"
            />
          </div>
          <div>
            <label>Giá gốc/niêm yết (đ)</label>
            <input
              type="number"
              value={form.costPrice}
              onChange={(e) => set("costPrice", Number(e.target.value) || 0)}
              placeholder="399000"
            />
          </div>

          <div>
            <label>Mô tả ngắn</label>
            <textarea
              value={form.shortDesc || ""}
              onChange={(e) => set("shortDesc", e.target.value)}
              placeholder="Hiển thị trong danh sách…"
            />
          </div>
          <div>
            <label>Mô tả chi tiết</label>
            <textarea
              value={form.description}
              onChange={(e) => set("description", e.target.value)}
              placeholder="Nội dung landing sản phẩm…"
            />
          </div>
        </div>
      </div>

      <div className="card" style={{ marginTop: 14 }}>
        <h2>Cấu hình hiển thị</h2>
        <div className="grid cols-3">
          <div>
            <label>Tiêu đề SEO</label>
            <input
              value={form.seoTitle || ""}
              onChange={(e) => set("seoTitle", e.target.value)}
              placeholder="Mua key Microsoft 365 Family giá tốt"
            />
          </div>
          <div>
            <label>Mô tả SEO</label>
            <input
              value={form.seoDesc || ""}
              onChange={(e) => set("seoDesc", e.target.value)}
              placeholder="Key chính hãng, giao nhanh, hỗ trợ 24/7"
            />
          </div>
          <div>
            <label>Ảnh đại diện</label>
            <input type="file" disabled title="Feature chưa kết nối media" />
          </div>
          <div>
            <label>Badge</label>
            <select value={form.badge || ""} onChange={(e) => set("badge", e.target.value)}>
              <option value="">—</option>
              <option value="featured">Nổi bật</option>
              <option value="hot">Giảm mạnh</option>
            </select>
          </div>
          <div>
            <label>Thứ tự ưu tiên</label>
            <input
              type="number"
              value={form.displayOrder || 0}
              onChange={(e) => set("displayOrder", Number(e.target.value) || 0)}
              placeholder="Số nhỏ hiển thị trước"
            />
          </div>
          <div>
            <label>Giới hạn hiển thị</label>
            <select value={form.channel || ""} onChange={(e) => set("channel", e.target.value)}>
              <option value="">Không</option>
              <option value="web">Chỉ web</option>
              <option value="app">Chỉ app</option>
            </select>
          </div>
        </div>
      </div>

      <div className="card" style={{ marginTop: 14 }}>
        <h2>Thiết lập theo loại</h2>
        <div className="grid cols-3">
          <div>
            <label>Hạn dùng (tháng)</label>
            <input
              value={form.expiryDate || ""}
              onChange={(e) => set("expiryDate", e.target.value)}
              placeholder="VD: 12"
            />
          </div>
          <div>
            <label>Giới hạn user/pool</label>
            <input
              value={form.poolNote || ""}
              onChange={(e) => set("poolNote", e.target.value)}
              placeholder="6 (Gói M365), hoặc seats/pool"
            />
          </div>
          <div>
            <label>Chính sách đổi trả</label>
            <select
              value={form.returnPolicy || "7d"}
              onChange={(e) => set("returnPolicy", e.target.value)}
            >
              <option value="7d">7 ngày</option>
              <option value="none">Không cho phép</option>
            </select>
          </div>
        </div>
        <div className="row" style={{ marginTop: 12 }}>
          <button className="btn" disabled={saving} onClick={() => save(false)}>Lưu nháp</button>
          <button className="btn primary" disabled={saving} onClick={() => save(true)}>Lưu & Xuất bản</button>
        </div>
      </div>
    </AdminLayout>
  );
}
