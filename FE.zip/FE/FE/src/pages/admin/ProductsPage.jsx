import React from "react";
import AdminLayout from "../../components/admin/Layout";
import { CategoryApi } from "../../services/categories";
import { ProductApi } from "../../services/products";

/**
 * Trang quản lý sản phẩm (gộp Danh mục + Sản phẩm)
 * - Khối 1: Danh mục sản phẩm (theo loại phần mềm)
 * - Khối 2: Danh sách sản phẩm + bộ lọc + CRUD nhanh
 * - Khối 3: Cập nhật giá hàng loạt (CSV / %)
 * - Khối 4: Cấu hình hiển thị trên website (local state demo)
 */
export default function ProductsPage() {
  // ====== Danh mục ======
  const [catQuery, setCatQuery] = React.useState({ keyword: "", code: "", active: "" });
  const [categories, setCategories] = React.useState([]);
  const [catLoading, setCatLoading] = React.useState(false);

  const loadCategories = React.useCallback(() => {
    setCatLoading(true);
    const params = { ...catQuery };
    if (params.active === "") delete params.active;
    CategoryApi.list(params)
      .then(setCategories)
      .finally(() => setCatLoading(false));
  }, [catQuery]);

  React.useEffect(() => { loadCategories(); }, [loadCategories]);

  const catToggle = async (id) => { await CategoryApi.toggle(id); loadCategories(); };
  const catDelete = async (id) => {
    if (!confirm("Xoá danh mục này?")) return;
    await CategoryApi.remove(id); loadCategories();
  };

  // Tạo/sửa nhanh (right-side form simplified)
  const [catEditing, setCatEditing] = React.useState(null); // null | 'create' | id
  const [catForm, setCatForm] = React.useState({ categoryCode:"", categoryName:"", description:"", isActive:true, displayOrder:0 });

  const catStartCreate = () => { setCatEditing("create"); setCatForm({ categoryCode:"", categoryName:"", description:"", isActive:true, displayOrder:0 }); };
  const catStartEdit = async (id) => {
    setCatEditing(id);
    const dto = await CategoryApi.get(id);
    setCatForm({
      categoryCode: dto.categoryCode,
      categoryName: dto.categoryName,
      description: dto.description,
      isActive: dto.isActive,
      displayOrder: dto.displayOrder ?? 0
    });
  };
  const catSave = async () => {
    if (catEditing === "create") {
      await CategoryApi.create(catForm);
    } else {
      await CategoryApi.update(catEditing, {
        categoryName: catForm.categoryName,
        description: catForm.description,
        isActive: catForm.isActive,
        displayOrder: catForm.displayOrder
      });
    }
    setCatEditing(null);
    loadCategories();
  };

  // Bulk upsert (nút “Tải danh mục / Lưu danh mục”)
  const bulkUpsert = async () => {
    const payload = categories.map(c => ({
      categoryCode: c.categoryCode,
      categoryName: c.categoryName,
      description: c.description || "",
      isActive: c.isActive,
      displayOrder: c.displayOrder ?? 0
    }));
    const res = await CategoryApi.bulkUpsert(payload);
    alert(`created: ${res.created}, updated: ${res.updated}`);
    loadCategories();
  };

  // ====== Sản phẩm ======
  const [products, setProducts] = React.useState([]);
  const [total, setTotal] = React.useState(0);
  const [q, setQ] = React.useState({
    keyword: "",
    categoryId: "",
    type: "",
    status: "",
    page: 1,
    pageSize: 10,
  });
  const [prodLoading, setProdLoading] = React.useState(false);

  const loadProducts = React.useCallback(() => {
    setProdLoading(true);
    const params = { ...q };
    if (params.categoryId === "") delete params.categoryId;
    if (params.type === "") delete params.type;
    if (params.status === "") delete params.status;

    ProductApi.list(params)
      .then(res => {
        setProducts(res.items || res.data || res);
        setTotal(res.total ?? res.totalCount ?? 0);
      })
      .finally(() => setProdLoading(false));
  }, [q]);

  React.useEffect(() => { loadProducts(); }, [loadProducts]);

  const delProduct = async (id) => {
    if (!confirm("Xoá sản phẩm này?")) return;
    await ProductApi.remove(id); loadProducts();
  };
  const changeStatus = async (id, status) => {
    await ProductApi.changeStatus(id, status); loadProducts();
  };

  // CSV + bulk %
  const exportCsv = async () => {
    const blob = await ProductApi.exportCsv();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "products_price.csv"; a.click();
    URL.revokeObjectURL(url);
  };
  const importCsv = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const res = await ProductApi.importPriceCsv(file);
    alert(`Total: ${res.total}, updated: ${res.updated}, notFound: ${res.notFound}, invalid: ${res.invalid}`);
    e.target.value = "";
    loadProducts();
  };
  const doBulkPercent = async () => {
    const percent = Number(prompt("Nhập % tăng/giảm (âm để giảm):", "5"));
    if (!percent || Number.isNaN(percent)) return;
    const res = await ProductApi.bulkPrice({ percent });
    alert(`Updated: ${res.updated} items`);
    loadProducts();
  };

  // ====== Cấu hình hiển thị (demo lưu local) ======
  const [ui, setUi] = React.useState({
    badgeLowStock: true,
    showShortDesc: true,
    filterShared: true,
    filterPersonal: true,
    filterService: true,
    sortDefault: "Nổi bật",
    perPage: 24,
    titleSeo: "Mua key phần mềm giá tốt",
    descSeo: "Key bản quyền chính hãng, giá rẻ.",
  });

  return (
    <AdminLayout>
      {/* ===== Khối 1: Danh mục ===== */}
      <div className="card">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <h2>Danh mục sản phẩm (theo loại phần mềm)</h2>
          <div className="row">
            <button className="btn" onClick={bulkUpsert}>Tải danh mục</button>
            <button className="btn primary" onClick={catStartCreate}>+ Thêm danh mục</button>
          </div>
        </div>

        <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: "wrap" }}>
          <input placeholder="VD: Office / Windows / Adobe / Khác" value={catQuery.keyword}
                 onChange={(e) => setCatQuery(s => ({ ...s, keyword: e.target.value }))} />
          <input placeholder="VD: office, windows, adobe" value={catQuery.code}
                 onChange={(e) => setCatQuery(s => ({ ...s, code: e.target.value }))} />
          <select value={catQuery.active} onChange={(e) => setCatQuery(s => ({ ...s, active: e.target.value }))}>
            <option value="">Hiển thị</option>
            <option value="true">Hiện</option>
            <option value="false">Ẩn</option>
          </select>
          <button className="btn" onClick={loadCategories}>Lưu danh mục</button>
          <button className="btn" onClick={() => setCatQuery({ keyword:"", code:"", active:"" })}>Reset</button>
        </div>

        <table className="table" style={{ marginTop: 10 }}>
          <thead><tr><th>Tên</th><th>Slug</th><th>Số SP</th><th>Trạng thái</th><th>Thao tác</th></tr></thead>
          <tbody>
            {categories.map(c => (
              <tr key={c.categoryId}>
                <td>{c.categoryName}</td>
                <td>{c.categoryCode}</td>
                <td>{c.productCount ?? 0}</td>
                <td><span className={c.isActive ? "badge green" : "badge gray"}>{c.isActive ? "Hiện" : "Ẩn"}</span></td>
                <td>
                  <button className="btn" onClick={() => catStartEdit(c.categoryId)}>✏️</button>
                  <button className="btn" onClick={() => catToggle(c.categoryId)}>👁</button>
                  <button className="btn" onClick={() => catDelete(c.categoryId)}>🗑</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* form nhỏ inline dưới bảng */}
        {catEditing && (
          <div className="card" style={{ marginTop: 10 }}>
            <h3 style={{ marginTop: 0 }}>{catEditing === "create" ? "Thêm danh mục" : "Sửa danh mục"}</h3>
            {catEditing === "create" && (
              <label>Slug (CategoryCode)
                <input value={catForm.categoryCode} onChange={(e) => setCatForm(f => ({ ...f, categoryCode: e.target.value }))} placeholder="office / windows / adobe" />
              </label>
            )}
            <div className="grid cols-2">
              <label>Tên
                <input value={catForm.categoryName} onChange={(e) => setCatForm(f => ({ ...f, categoryName: e.target.value }))} />
              </label>
              <label>Hiển thị
                <select value={catForm.isActive ? "true" : "false"}
                        onChange={(e) => setCatForm(f => ({ ...f, isActive: e.target.value === "true" }))}>
                  <option value="true">Hiện</option>
                  <option value="false">Ẩn</option>
                </select>
              </label>
              <label style={{ gridColumn: "1/3" }}>Mô tả
                <textarea value={catForm.description || ""} onChange={(e) => setCatForm(f => ({ ...f, description: e.target.value }))} />
              </label>
              <label>Thứ tự
                <input type="number" value={catForm.displayOrder ?? 0}
                       onChange={(e) => setCatForm(f => ({ ...f, displayOrder: Number(e.target.value) }))} />
              </label>
            </div>
            <div className="row" style={{ marginTop: 10 }}>
              <button className="btn" onClick={() => setCatEditing(null)}>Huỷ</button>
              <button className="btn primary" onClick={catSave}>Lưu</button>
            </div>
          </div>
        )}
      </div>

      {/* ===== Khối 2: Sản phẩm ===== */}
      <div className="card" style={{ marginTop: 14 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <h2>Danh sách sản phẩm</h2>
          <div className="row">
            <button className="btn" onClick={doBulkPercent}>↻ Cập nhật giá</button>
            <label className="btn">
              ⬆ Nhập CSV
              <input type="file" accept=".csv" style={{ display: "none" }} onChange={importCsv} />
            </label>
            <button className="btn" onClick={exportCsv}>⬇ Xuất CSV</button>
            <a className="btn primary" href="/admin/products/add">+ Thêm sản phẩm</a>
          </div>
        </div>

        <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: "wrap" }}>
          <input placeholder="Tên, SKU, mô tả…" value={q.keyword} onChange={(e) => setQ(s => ({ ...s, keyword: e.target.value, page:1 }))} />
          <select value={q.categoryId} onChange={(e) => setQ(s => ({ ...s, categoryId: e.target.value, page:1 }))}>
            <option value="">Danh mục</option>
            {categories.map(c => <option key={c.categoryId} value={c.categoryId}>{c.categoryName}</option>)}
          </select>
          <select value={q.type} onChange={(e) => setQ(s => ({ ...s, type: e.target.value, page:1 }))}>
            <option value="">Loại</option>
            <option value="SOFTWARE">SOFTWARE</option>
            <option value="SERVICE">SERVICE</option>
            <option value="LICENSE">LICENSE</option>
          </select>
          <select value={q.status} onChange={(e) => setQ(s => ({ ...s, status: e.target.value, page:1 }))}>
            <option value="">Trạng thái</option>
            <option value="ACTIVE">ACTIVE</option>
            <option value="INACTIVE">INACTIVE</option>
            <option value="OUT_OF_STOCK">OUT_OF_STOCK</option>
          </select>
          <button className="btn primary" onClick={loadProducts}>Áp dụng</button>
          <button className="btn" onClick={() => setQ({ keyword:"", categoryId:"", type:"", status:"", page:1, pageSize:q.pageSize })}>Reset</button>
        </div>

        <table className="table" style={{ marginTop: 10 }}>
          <thead>
            <tr>
              <th>Mã SP</th><th>Tên sản phẩm</th><th>Loại</th><th>Giá</th><th>Tồn</th><th>Bảo hành</th><th>Trạng thái</th><th>Thao tác</th>
            </tr>
          </thead>
          <tbody>
            {products.map(p => (
              <tr key={p.productId}>
                <td>{p.productCode}</td>
                <td>{p.productName}</td>
                <td>{p.productType}</td>
                <td>{p.salePrice}</td>
                <td>{p.stockQty}</td>
                <td>{p.warrantyDays}</td>
                <td>
                  <select value={p.status} onChange={(e) => changeStatus(p.productId, e.target.value)}>
                    <option value="ACTIVE">ACTIVE</option>
                    <option value="INACTIVE">INACTIVE</option>
                    <option value="OUT_OF_STOCK">OUT_OF_STOCK</option>
                  </select>
                </td>
                <td>
                  <button className="btn" title="Xoá" onClick={() => delProduct(p.productId)}>🗑</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="pager">
          <button disabled={q.page <= 1} onClick={() => setQ(s => ({ ...s, page: s.page - 1 }))}>Prev</button>
          <span style={{ padding: "0 8px" }}>Trang {q.page}</span>
          <button disabled={q.page * q.pageSize >= total} onClick={() => setQ(s => ({ ...s, page: s.page + 1 }))}>Next</button>
        </div>
      </div>

      {/* ===== Khối 3: Cập nhật giá hàng loạt ===== */}
      <div className="card" style={{ marginTop: 14 }}>
        <h2>Cập nhật giá hàng loạt</h2>
        <div className="grid cols-3">
          <div>
            <label>Phạm vi</label>
            <select><option>Tất cả sản phẩm</option></select>
          </div>
          <div>
            <label>Kiểu cập nhật</label>
            <select><option>Tăng/giảm theo %</option></select>
          </div>
          <div>
            <label>Giá trị</label>
            <input placeholder="% hoặc số tiền" />
          </div>
          <div>
            <label>Tải tệp (tuỳ chọn)</label>
            <input type="file" accept=".csv" onChange={importCsv} />
          </div>
          <div>
            <label>Xem trước thay đổi</label>
            <div className="kbd">CSV: sku, new_price</div>
          </div>
        </div>
        <div className="row" style={{ marginTop: 12 }}>
          <button className="btn" onClick={() => {}}>Hủy</button>
          <button className="btn primary" onClick={doBulkPercent}>Áp dụng giá</button>
          <button className="btn" onClick={exportCsv}>Xuất CSV sản phẩm</button>
        </div>
      </div>

      {/* ===== Khối 4: Cấu hình hiển thị trên website (demo) ===== */}
      <div className="card" style={{ marginTop: 14 }}>
        <h2>Cấu hình hiển thị trên website</h2>
        <div className="grid cols-2">
          <div>
            <label>Tùy chọn hiển thị</label>
            <div className="row" style={{ gap: 12, flexWrap: "wrap" }}>
              <label className="badge">
                <input type="checkbox" checked={ui.badgeLowStock} onChange={e => setUi(s => ({ ...s, badgeLowStock: e.target.checked }))} /> Hiện badge "Sắp hết hàng"
              </label>
              <label className="badge">
                <input type="checkbox" checked={ui.showShortDesc} onChange={e => setUi(s => ({ ...s, showShortDesc: e.target.checked }))} /> Hiển mô tả rút gọn
              </label>
              <label className="badge">
                <input type="checkbox" checked={ui.filterShared} onChange={e => setUi(s => ({ ...s, filterShared: e.target.checked }))} /> Cho phép lọc "Key dùng chung"
              </label>
              <label className="badge">
                <input type="checkbox" checked={ui.filterPersonal} onChange={e => setUi(s => ({ ...s, filterPersonal: e.target.checked }))} /> Cho phép lọc "Key cá nhân"
              </label>
              <label className="badge">
                <input type="checkbox" checked={ui.filterService} onChange={e => setUi(s => ({ ...s, filterService: e.target.checked }))} /> Cho phép lọc "Gói dịch vụ"
              </label>
            </div>
          </div>
          <div>
            <label>Sắp xếp & SEO</label>
            <div className="grid cols-2">
              <input value={ui.sortDefault} onChange={(e) => setUi(s => ({ ...s, sortDefault: e.target.value }))} placeholder="Thứ tự mặc định" />
              <select value={ui.perPage} onChange={(e) => setUi(s => ({ ...s, perPage: Number(e.target.value) }))}>
                <option value={12}>12</option><option value={24}>24</option><option value={36}>36</option>
              </select>
              <input value={ui.titleSeo} onChange={(e) => setUi(s => ({ ...s, titleSeo: e.target.value }))} placeholder="Tiêu đề trang (SEO)" />
              <input value={ui.descSeo} onChange={(e) => setUi(s => ({ ...s, descSeo: e.target.value }))} placeholder="Mô tả trang (SEO)" />
            </div>
          </div>
        </div>
        <div className="row" style={{ marginTop: 12 }}>
          <button className="btn">Khôi phục mặc định</button>
          <button className="btn primary" onClick={() => alert("Đã lưu cấu hình (demo local)")}>Lưu cấu hình</button>
        </div>
      </div>
    </AdminLayout>
  );
}
