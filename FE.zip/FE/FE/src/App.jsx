
import React from "react"
import { Routes, Route, Navigate } from "react-router-dom"
import ProductsPage from "./pages/admin/ProductsPage.jsx"
import CategoryAdd from "./pages/admin/CategoryAdd.jsx"
import ProductAdd from "./pages/admin/ProductAdd.jsx"
import AdminLayout from "./components/admin/Layout.jsx"

function Home(){
  return (
    <AdminLayout>
      <div className="card"><h2>Màn hình chính</h2><p>Bảng điều khiển nhanh.</p></div>
    </AdminLayout>
  )
}

export default function App(){
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/admin" replace />} />
      <Route path="/admin" element={<Home/>} />
      <Route path="/admin/products" element={<ProductsPage />} />
      <Route path="/admin/products/add" element={<ProductAdd />} />
      <Route path="/admin/categories/add" element={<CategoryAdd />} />
      <Route path="*" element={<Navigate to="/admin" replace />} />
    </Routes>
  )
}
