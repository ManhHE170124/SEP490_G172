import api from "../apiClient";

export const ProductApi = {
  list: (params = {}) =>
    api.get("/products/list", { params }).then((r) => r.data),

  get: (id) => api.get(`/products/${id}`).then((r) => r.data),

  create: (payload) => api.post("/products", payload).then((r) => r.data),

  update: (id, payload) =>
    api.put(`/products/${id}`, payload).then((r) => r.data),

  remove: (id) => api.delete(`/products/${id}`).then((r) => r.data),

  changeStatus: (id, status) =>
    api
      .patch(`/products/${id}/status`, JSON.stringify(status), {
        headers: { "Content-Type": "application/json" },
      })
      .then((r) => r.data),

  bulkPrice: (payload) =>
    api.post("/products/bulk-price", payload).then((r) => r.data),

  exportCsv: () =>
    api.get("/products/export-csv", { responseType: "blob" }).then((r) => r.data),

  importPriceCsv: (file) => {
    const form = new FormData();
    form.append("file", file);
    return api
      .post("/products/import-price-csv", form, {
        headers: { "Content-Type": "multipart/form-data" },
      })
      .then((r) => r.data);
  },
};
