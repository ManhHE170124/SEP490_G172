import React from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import AdminLayout from "../../components/admin/Layout";
import { CategoryApi } from "../../services/categories";

export default function CategoryDetail() {
  const { id } = useParams();                // /admin/categories/:id
  const catId = Number(id);
  const nav = useNavigate();

  const [loading, setLoading] = React.useState(true);
  const [saving, setSaving] = React.useState(false);
  const [notFound, setNotFound] = React.useState(false);

  const [form, setForm] = React.useState({
    categoryCode: "",
    categoryName: "",
    description: "",
    isActive: true,
    displayOrder: 0,
  });

  const load = React.useCallback(async () => {
    try {
      setLoading(true);
      setNotFound(false);
      const dto = await CategoryApi.get(catId);
      if (!dto) { setNotFound(true); return; }
      setForm({
        categoryCode: dto.categoryCode || "",
        categoryName: dto.categoryName || "",
        description: dto.description || "",
        isActive: !!dto.isActive,
        displayOrder: dto.displayOrder ?? 0,
      });
    } catch (e) {
      setNotFound(true);
    } finally {
      setLoading(false);
    }
  }, [catId]);

  React.useEffect(() => { load(); }, [load]);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const save = async () => {
    try {
      setSaving(true);
      await CategoryApi.update(catId, {
        categoryName: form.categoryName.trim(),
        description: form.description,
        isActive: form.isActive,
        displayOrder: Number(form.displayOrder) || 0,
      });
      alert("Đã lưu thay đổi.");
      await load();
    } finally {
      setSaving(false);
    }
  };

  const toggle = async () => {
    await CategoryApi.toggle(catId);
    await load();
  };

  if (loading) {
    return (
      <AdminLayout>
        <div className="card"><div>Đang tải chi tiết danh mục…</div></div>
      </AdminLayout>
    );
  }

  if (notFound) {
    return (
      <AdminLayout>
        <div className="card">
          <div className="row" style={{justifyContent:"space-between", alignItems:"center"}}>
            <h2>Không tìm thấy danh mục</h2>
            <Link className="btn" to="/admin/categories">← Quay lại danh sách</Link>
          </div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="card">
        <div className="row" style={{justifyContent:"space-between", alignItems:"center"}}>
          <div>
            <h2 style={{margin:0}}>Chi tiết danh mục</h2>
            <div className="muted">
              Chỉnh sửa thông tin và trạng thái hiển thị trên website.
            </div>
          </div>
          <div className="row" style={{gap:8}}>
            <button className="btn" onClick={toggle}>
              {form.isActive ? "Ẩn (toggle)" : "Hiện (toggle)"}
            </button>
            <button className="btn primary" onClick={save} disabled={saving}>
              {saving ? "Đang lưu…" : "Lưu thay đổi"}
            </button>
            <Link className="btn" to="/admin/categories">← Quay lại danh sách</Link>
          </div>
        </div>

        <div className="grid cols-2" style={{marginTop:12, gap:16}}>
          <div>
            <label>Tên danh mục <span className="badge">bắt buộc</span></label>
            <input
              value={form.categoryName}
              onChange={(e)=>set("categoryName", e.target.value)}
              placeholder="VD: Windows, Office, Antivirus…"
            />
          </div>

          <div>
            <label>Slug (CategoryCode)</label>
            <input
              value={form.categoryCode}
              disabled
              className="mono"
              title="Slug do BE chuẩn hoá; không sửa tại trang chi tiết"
            />
            <div className="muted">Slug được chuẩn hoá ở BE và không thể chỉnh tại đây.</div>
          </div>

          <div className="col-span-2">
            <label>Mô tả</label>
            <textarea
              rows={4}
              value={form.description || ""}
              onChange={(e)=>set("description", e.target.value)}
              placeholder="Mô tả ngắn về danh mục…"
            />
          </div>

          <div>
            <label>Thứ tự hiển thị</label>
            <input
              type="number"
              value={form.displayOrder}
              onChange={(e)=>set("displayOrder", e.target.value)}
              min={0}
            />
          </div>

          <div>
            <label>Trạng thái</label>
            <div className="row" style={{alignItems:"center", gap:12}}>
              <label className="badge">
                <input
                  type="checkbox"
                  checked={form.isActive}
                  onChange={(e)=>set("isActive", e.target.checked)}
                /> Đang hiển thị
              </label>
              <span className={`badge ${form.isActive ? "" : "gray"}`}>
                {form.isActive ? "Active" : "Inactive"}
              </span>
            </div>
          </div>
        </div>

        <div className="row" style={{marginTop:16, gap:8}}>
          <button className="btn" onClick={()=>nav(-1)}>← Quay lại</button>
          <button className="btn primary" onClick={save} disabled={saving}>
            {saving ? "Đang lưu…" : "Lưu thay đổi"}
          </button>
        </div>
      </div>
    </AdminLayout>
  );
}
