// src/services/products.js
import api from "../apiClient";

export const ProductApi = {
  // GET /products/list?...
  list(params = {}) {
    return api.get("/products/list", { params }).then((r) => r.data); // expect { items, total }
  },

  get(id) {
    return api.get(`/products/${id}`).then((r) => r.data);
  },

  create(payload) {
    return api.post("/products", payload).then((r) => r.data);
  },

  update(id, payload) {
    return api.put(`/products/${id}`, payload).then((r) => r.data);
  },

  remove(id) {
    return api.delete(`/products/${id}`).then((r) => r.data);
  },

  // PATCH { status } (đã fix không gửi raw string)
  changeStatus(id, status) {
    return api.patch(`/products/${id}/status`, { status }).then((r) => r.data);
  },

  bulkPrice(payload) {
    return api.post("/products/bulk-price", payload).then((r) => r.data);
  },

  exportCsv() {
    return api
      .get("/products/export-csv", { responseType: "blob" })
      .then((r) => r.data);
  },

  importPriceCsv(file) {
    const form = new FormData();
    form.append("file", file);
    return api
      .post("/products/import-price-csv", form, {
        headers: { "Content-Type": "multipart/form-data" },
      })
      .then((r) => r.data);
  },
};
