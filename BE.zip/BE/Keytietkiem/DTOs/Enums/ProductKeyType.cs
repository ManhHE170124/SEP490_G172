namespace Keytietkiem.DTOs.Enums;

public enum ProductKeyType
{
    Individual,
    Pool
}