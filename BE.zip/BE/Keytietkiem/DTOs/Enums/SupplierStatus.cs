namespace Keytietkiem.DTOs.Enums;

public enum SupplierStatus
{
    Active,
    Deactive
}