namespace Keytietkiem.DTOs.Enums;

public enum ProductKeyStatus
{
    Available,
    Error,
    OverLimit
}